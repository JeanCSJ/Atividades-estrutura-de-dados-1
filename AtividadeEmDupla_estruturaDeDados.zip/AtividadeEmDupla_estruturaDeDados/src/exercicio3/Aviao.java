package exercicio3;

public class Aviao {
	String nome;
	int id;
}
