package exercicio8;

public class Main {

	public static void main(String[] args) {
		TestaPilha.criarpilha();
		TestaPilha.imprimirPilhas();

	}

}
